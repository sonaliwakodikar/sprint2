import React from 'react';
function StaffDashBoard(){
    // const [url,setUrl]=useState("");
    const user=JSON.parse(localStorage.getItem("Details"));

    return(
        <div>Staff Services here</div>
    )
}
export default StaffDashBoard;