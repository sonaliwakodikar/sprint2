import React from "react";
function Logout(){
    const user=JSON.parse(localStorage.getItem("Details"));

    const handleButton=()=>{
       if(user!==null){
        localStorage.removeItem("Details");
        alert("Logged Off");
       }
    }
    return(
        <div>
            <button onClick={handleButton}>Logout</button>
        </div>
    )
}

export default Logout;