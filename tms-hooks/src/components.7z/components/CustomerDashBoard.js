import React from 'react';
import CustomerMenu from './CustomerMenu';
import {useNavigate} from 'react-router-dom';
import AvailTour from './AvailabaleTours';

function CustomerDashBoard(){
    // const navigate=useNavigate();
    // const user = JSON.parse(localStorage.getItem("Details"));
    // if(user.userType!=="Customer"){
    //     alert("Please Login as Customer");
    //     navigate(`/user/login`)
    // }
    return(<div>
        <div className='CDashBoard'>
            <CustomerMenu/>
        </div>
        <AvailTour/>
    </div>)
}
export default CustomerDashBoard;